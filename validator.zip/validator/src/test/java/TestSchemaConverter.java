import org.testng.annotations.Test;
import validator.SchemaConverter;

import java.util.HashMap;

public class TestSchemaConverter {

    @Test
    public void testSchemaValidator() {
        String schema = "{\"web_pages\": \"String\"}";
        HashMap<String, Class<?>> stringClassHashMap = SchemaConverter.ConvertToHashMap(schema);
        System.out.println(stringClassHashMap);
    }

}
