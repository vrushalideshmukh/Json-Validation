package validator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class BaseValidator {

    String toValidate;
    HashMap<String, Class<?>> schema;
    Integer validatedItems = 0;
    List<String> errorMessages = new ArrayList<String>();

    public BaseValidator(String validateStr, HashMap<String, Class<?>> schema) {
        this.toValidate = validateStr;
        this.schema = schema;
    }

    public boolean validate() {
        try {
            JSONArray items = new JSONArray(this.toValidate);
            for (int i = 0; i < items.length(); i++) {
                JSONObject object = items.getJSONObject(i);
                this.validateObjectAgainstSchema(object);
            }
        }catch (Exception e) {
            return false;
        }
        System.out.println("\nTotal validated Objects " + this.validatedItems);
        return true;
    }

    private void validateObjectAgainstSchema(JSONObject object) {
        try {
            Set<String> keys = schema.keySet();
            for (String key : keys) {
                if(object.has(key)) {
                    Object value = object.get(key);
                    if (value == null) {
                        continue;
                    }else {
                        if(value.getClass().equals(schema.get(key))) {
                            System.out.println("VALIDATED : " + key);
                            this.validatedItems++;
                        }
                    }
                }else {
                    errorMessages.add("Keys "+ key + " does not exist in json object");
                }
            }
        }catch (Exception e ) {
            errorMessages.add(e.getMessage());
        }
    }

}
