package validator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Set;

// assign class type to schema key
public class SchemaConverter {
    public static HashMap<String, Class<?>> ConvertToHashMap(String schema) {
        HashMap<String, Class<?>> map = new HashMap<>();
        JSONObject o = new JSONObject(schema);
        Set<String> keys = o.keySet();
        for (String key: keys) {
            switch (o.getString(key)) {
                case "Array":
                    map.put(key, JSONArray.class);
                    break;
                case "Integer":
                    map.put(key, Integer.class);
                    break;
                case "Boolean":
                    map.put(key, Boolean.class);
                    break;
                case "String":
                    map.put(key, String.class);
                    break;
            }
        }
        return map;
    }
}
