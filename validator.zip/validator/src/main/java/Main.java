import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import validator.BaseValidator;
import validator.SchemaConverter;

import java.util.HashMap;

public class Main {
    public static void main(String[] args) throws UnirestException {
        // download json response from url
        HttpResponse<String> response = Unirest.get("https://gist.githubusercontent.com/ab9-er/27a903b8636e745fb820a7d310177c46/raw/1263a2e60ce6576da2e0812b37f775e89f50d744/world_universities_and_domains.json").asString();

        // read json string from response
        String responseJsonString = response.getBody();

        // define schema to check against above downloaded response
        String schema = "{\n" +
                "  \"web_pages\": \"Array\",\n" +
                "  \"name\": \"String\",\n" +
                "  \"alpha_two_code\": \"String\",\n" +
                "  \"state-province\": \"String\",\n" +
                "  \"domains\": \"Array\",\n" +
                "  \"country\": \"String\"\n" +
                "}";

        // converting schema into map to assign java class
        HashMap<String, Class<?>> convertedSchema = SchemaConverter.ConvertToHashMap(schema);

        // pass response string and schema map
        BaseValidator validator = new BaseValidator(responseJsonString, convertedSchema);

        validator.validate();
    }
}
