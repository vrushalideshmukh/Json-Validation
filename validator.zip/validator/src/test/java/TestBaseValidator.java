//import com.sun.tools.javac.code.Attribute;
import org.json.JSONArray;
import org.testng.annotations.Test;
import sun.reflect.Reflection;
import validator.BaseValidator;

import java.util.HashMap;
import java.util.List;

public class TestBaseValidator {

    @Test
    public void testValidator() {
        String v = "[{\"name\": \"GOD\", \"value\": 10, \"boolean\": true, \"array\": [\"akash\"]}]";
        HashMap<String, Class<?>> schema = new HashMap<>();
        schema.put("name", String.class);
        schema.put("value", Integer.class);
        schema.put("boolean", Boolean.class);
        schema.put("array", JSONArray.class);
        BaseValidator validator = new BaseValidator(v, schema);
        boolean validate = validator.validate();
        System.out.println("VALIDATED "+ validate);
    }

}
